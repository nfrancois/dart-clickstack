TodoMVC sample application written with the Dart Web UI package, which includes
web components and MDV templates bound to models.

To run this code, launch "web/main.html". If you encounter an error about a 
missing "web/out/main.html" file, right click on "build.dart" and select "Run".

Generated code will be created under "web/out/". Any time you edit and save a 
source file, the necessary files will be regenerated automatically. Look at
"build.dart" to see how this works.

You can also find this example on the development site for the Dart Web UI
package:

  https://github.com/dart-lang/web-ui/tree/master/example/todomvc

