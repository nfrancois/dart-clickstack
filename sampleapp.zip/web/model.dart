// Copyright (c) 2013, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

library model;

import 'package:web_ui/observe.dart';
import 'package:web_ui/observe/html.dart';
import 'package:web_ui/observe/observable.dart' as __observe;


@observable
class ViewModel {
  bool isVisible(Todo todo) => todo != null &&
      ((showIncomplete && !todo.done) || (showDone && todo.done));

  bool get showIncomplete => locationHash != '#/completed';

  bool get showDone => locationHash != '#/active';
}

final ViewModel viewModel = new ViewModel();

// The real model:

@observable
class AppModel {
  final ObservableList<Todo> todos = new ObservableList<Todo>();

  bool get allChecked => todos.length > 0 && todos.every((t) => t.done);

  set allChecked(bool value) => todos.forEach((t) { t.done = value; });

  int get doneCount =>
      todos.fold(0, (count, t) => count + (t.done ? 1 : 0));

  int get remaining => todos.length - doneCount;

  void clearDone() => todos.removeWhere((t) => t.done);
}

final AppModel app = new AppModel();

@observable
class Todo  extends Observable {
  String __$task;
  String get task {
    if (__observe.observeReads) {
      __observe.notifyRead(this, __observe.ChangeRecord.FIELD, 'task');
    }
    return __$task;
  }
  set task(String value) {
    if (__observe.hasObservers(this)) {
      __observe.notifyChange(this, __observe.ChangeRecord.FIELD, 'task',
          __$task, value);
    }
    __$task = value;
  }
  bool __$done = false;
  bool get done {
    if (__observe.observeReads) {
      __observe.notifyRead(this, __observe.ChangeRecord.FIELD, 'done');
    }
    return __$done;
  }
  set done(bool value) {
    if (__observe.hasObservers(this)) {
      __observe.notifyChange(this, __observe.ChangeRecord.FIELD, 'done',
          __$done, value);
    }
    __$done = value;
  }

  Todo(task) : __$task = task;

  String toString() => "$task ${done ? '(done)' : '(not done)'}";
}

//@ sourceMappingURL=model.dart.map